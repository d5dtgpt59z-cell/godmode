local P=dofile('/Users/ryanmorrison/Documents/Codex/2026-10-25/visit-https-cerebralvalley-ai-e-meta/outputs/godmode/art/pixel-core.lua')
local residents={'iona','bram','leda','kitt','moss','ada','tomas','orin','june','nell','pip','sela','rook','mara','dara','vale','wren','ivo','elin','bo','fenn','joss','tavi','una'}
local roles={'granary keeper','porter','porter','porter','porter','baker','baker','timber worker','timber worker','builder','builder','well tender','innkeeper','market clerk','stallholder','stallholder','courier','bell keeper','supper cook','householder','householder','householder','householder','householder'}
local ramps={{48,49,50},{51,52,53},{54,55,56},{57,58,59},{60,61,62},{5,7,9},{20,21,22},{11,13,14}}
local actions={{'idle',2,650},{'walk',4,140},{'carry',4,160},{'talk',2,240},{'work',4,180},{'rest',2,850}}
local dirs={'s','w','e','n'}
local function character(v,dir,action,frame)
 local im=P.image(16,24);local ramp=ramps[(v-1)%8+1];local skin=v%3==0 and {45,46,47} or {41,42,43};local hair=({10,12,39,4,33,54})[(v-1)%6+1];local hairlight=({12,14,40,6,35,56})[(v-1)%6+1];local hat=math.floor((v-1)/8);local apron=v==6 or v==7 or v==19;local moving=action=='walk' or action=='carry';local bob=moving and ((frame==1 or frame==3) and 1 or 0) or 0;local rest=action=='rest';local oy=rest and 4 or bob
 -- A persistent, small contact shadow. The same bottom-center foot anchor is kept in every pose.
 P.ellipse(im,8,22,5,1,app.pixelColor.rgba(16,25,30,70))
 local phase=moving and ({0,-1,0,1})[frame+1] or 0
 if rest then
  P.rect(im,4,19,4,3,2);P.rect(im,8,20,4,2,3);P.rect(im,3,21,4,2,10);P.rect(im,9,22,4,2,10);P.p(im,4,21,13);P.p(im,10,22,13)
 elseif dir=='s' or dir=='n' then
  P.rect(im,5,17+bob,3,5-phase,1);P.rect(im,8,17+bob,3,5+phase,1)
  P.rect(im,5,18+bob,2,3-phase,dir=='n' and 3 or 4);P.rect(im,9,18+bob,2,3+phase,dir=='n' and 2 or 3)
  P.rect(im,4,21-phase,4,2,10);P.rect(im,8,21+phase,4,2,10);P.p(im,4,21-phase,13);P.p(im,8,21+phase,12)
 else
  local left=dir=='w';local frontx=left and 6 or 8;local backx=left and 9 or 5
  P.rect(im,backx,17+bob,2,5+phase,2);P.rect(im,frontx,17+bob,3,5-phase,4)
  P.rect(im,backx-(left and 1 or 0),21+phase,3,2,10);P.rect(im,frontx-(left and 2 or 0),21-phase,4,2,10);P.p(im,frontx-(left and 2 or 0),21-phase,13)
 end
 -- Shaped tunic, shoulder seams, belt and readable folds.
 P.rect(im,5,9+oy,6,9,1);P.rect(im,4,10+oy,8,5,1);P.rect(im,5,10+oy,6,7,ramp[2]);P.rect(im,5,11+oy,2,5,ramp[3]);P.rect(im,9,10+oy,2,7,ramp[1]);P.rect(im,5,16+oy,6,2,ramp[1]);P.p(im,6,15+oy,ramp[3]);P.p(im,8,14+oy,ramp[1])
 if apron then P.rect(im,6,11+oy,4,6,7);P.rect(im,6,11+oy,1,5,9);P.rect(im,9,12+oy,1,5,6);P.p(im,7,15+oy,8) end
 P.rect(im,5,17+oy,6,1,10);P.p(im,7,17+oy,39)
 if dir=='n' then P.rect(im,5,10+oy,6,2,ramp[1]);P.rect(im,6,12+oy,1,4,ramp[2]);P.p(im,9,15+oy,ramp[3]) end
 -- Arms; action-specific silhouettes, not a generic bob of the whole sprite.
 if action=='carry' then
  P.rect(im,3,11+oy,2,6,1);P.rect(im,4,12+oy,2,3,ramp[2]);P.rect(im,10,11+oy,3,5,1);P.rect(im,10,12+oy,2,3,ramp[1]);P.rect(im,5,14+oy,6,3,11);P.rect(im,5,14+oy,6,1,14);P.rect(im,5,15+oy,1,2,skin[2]);P.rect(im,10,15+oy,1,2,skin[1]);P.line(im,6,16+oy,9,16+oy,13)
 elseif action=='work' then
  local lifts=({0,3,6,2})[frame+1];P.line(im,4,11+oy,3,16+oy-lifts,1);P.line(im,3,12+oy,3,15+oy-lifts,ramp[3]);P.p(im,3,16+oy-lifts,skin[3]);P.line(im,11,11+oy,12,16+oy-lifts,1);P.line(im,11,12+oy,12,15+oy-lifts,ramp[1]);P.p(im,12,16+oy-lifts,skin[2]);if v>=8 and v<=11 then P.line(im,12,15+oy-lifts,13,10+oy-lifts,13);P.rect(im,11,9+oy-lifts,4,2,3);P.p(im,11,9+oy-lifts,6) elseif apron then P.line(im,12,15+oy-lifts,13,10+oy-lifts,13);P.ellipse(im,13,10+oy-lifts,1,2,14) end
 elseif action=='talk' then
  P.rect(im,3,11+oy,2,6,1);P.rect(im,3,12+oy,1,4,ramp[3]);P.p(im,3,17+oy,skin[2]);P.line(im,11,11+oy,13,12+oy-frame*2,1);P.p(im,12,11+oy-frame*2,ramp[2]);P.p(im,13,11+oy-frame*2,skin[3]);P.p(im,14,10+oy-frame*2,skin[2])
 elseif rest then
  P.rect(im,3,12+oy,2,5,1);P.rect(im,11,12+oy,2,5,1);P.line(im,4,15+oy,7,16+oy-frame,skin[2]);P.line(im,11,15+oy,8,16+oy-frame,skin[1])
 else
  local swing=moving and phase or frame;P.rect(im,3,11+oy-swing,2,6,1);P.rect(im,3,12+oy-swing,1,4,ramp[3]);P.p(im,3,17+oy-swing,skin[2]);P.rect(im,11,11+oy+swing,2,6,1);P.rect(im,11,12+oy+swing,1,4,ramp[1]);P.p(im,11,17+oy+swing,skin[1])
 end
 -- Neck and head. Side profiles preserve global lighting rather than mirrored highlights.
 P.rect(im,7,8+oy,3,2,skin[1]);P.rect(im,6,3+oy,5,6,1)
 if dir=='s' then
  P.rect(im,5,4+oy,7,4,1);P.rect(im,6,3+oy,5,5,skin[2]);P.rect(im,6,4+oy,2,3,skin[3]);P.rect(im,7,7+oy,3,2,skin[2]);P.p(im,6,5+oy,1);P.p(im,9,5+oy,1);P.p(im,8,6+oy,skin[1]);P.p(im,8,8+oy,skin[1])
 elseif dir=='n' then
  P.rect(im,5,3+oy,7,5,1);P.rect(im,6,3+oy,5,5,hair);P.rect(im,6,3+oy,2,3,hairlight);P.p(im,10,7+oy,skin[1])
 else
  local right=dir=='e';local x=right and 7 or 4;P.rect(im,x,3+oy,5,5,skin[2]);P.rect(im,x,3+oy,2,4,skin[3]);P.p(im,right and 12 or 3,6+oy,skin[2]);P.p(im,right and 11 or 4,5+oy,1);P.p(im,right and 10 or 5,8+oy,skin[1]);P.rect(im,right and 6 or 8,3+oy,3,5,hair)
 end
 P.rect(im,6,2+oy,5,2,hair);P.rect(im,5,3+oy,2,2,hair);P.p(im,6,2+oy,hairlight);P.p(im,7,2+oy,hairlight)
 if hat==1 then P.rect(im,5,2+oy,6,2,ramp[1]);P.rect(im,5,2+oy,4,1,ramp[3]);P.rect(im,4,4+oy,8,1,ramp[2])
 elseif hat==2 then P.rect(im,5,2+oy,6,2,hair);P.rect(im,4,3+oy,2,5,hair);P.rect(im,4,7+oy,2,4,hair);P.p(im,4,4+oy,hairlight);P.p(im,4,8+oy,hairlight) end
 if apron then P.rect(im,5,1+oy,7,2,7);P.rect(im,6,0+oy,5,2,9);P.p(im,10,1+oy,8) end
 if moving and frame==2 then P.p(im,6,19+oy,3);P.p(im,9,20+oy,4);P.p(im,6,15+oy,ramp[1]) end
 if v==1 then P.p(im,11,12+oy,39);P.p(im,11,13+oy,40) end
 return im
end
local a=P.atlas('characters',512,1664)
local animationIndex={};local residentInfo={};local sample=P.image(24*22,4*34)
local base=Sprite(16,24,ColorMode.RGB);base.layers[1].name='Shared rig — Iona';if base.cels[1] then base:deleteCel(base.cels[1]) end
local master=Sprite(16,24,ColorMode.RGB);if master.cels[1] then master:deleteCel(master.cels[1]) end
local poseContact=P.image(18*20,4*30)
local baseFrame=0
for v,name in ipairs(residents) do
 local layer=v==1 and master.layers[1] or master:newLayer();layer.name=name;layer.isVisible=v==1;local poseIndex=0
 residentInfo[#residentInfo+1]={id=name,name=name:sub(1,1):upper()..name:sub(2),role=roles[v],variant=v,anchor={x=8,y=23},cargoAnchor={x=8,y=14}}
 for di,dir in ipairs(dirs) do
  for _,act in ipairs(actions) do
   local seq={}
   for f=0,act[2]-1 do
    local im=character(v,dir,act[1],f);local key=name..'.'..act[1]..'.'..dir..'.'..f;a:add(key,im,act[3],{x=8,y=23});seq[#seq+1]=key
    poseIndex=poseIndex+1;if v==1 and poseIndex>1 then master:newEmptyFrame() end;master.frames[poseIndex].duration=act[3]/1000;master:newCel(layer,poseIndex,im,Point(0,0))
    if v==1 then poseContact:drawImage(im,Point(((poseIndex-1)%18)*20+2,math.floor((poseIndex-1)/18)*30+3)) end
    if v==1 then baseFrame=baseFrame+1;if baseFrame>1 then base:newEmptyFrame() end;local fr=base.frames[baseFrame];fr.duration=act[3]/1000;base:newCel(base.layers[1],baseFrame,im,Point(0,0)) end
   end
   local anim=name..'.'..act[1]..'.'..dir;a.animations[anim]={frames=seq,duration=act[3],repeatCount=-1};animationIndex[anim]=seq
  end
  sample:drawImage(character(v,dir,'idle',0),Point((v-1)*22+3,(di-1)*34+5))
 end
end
-- Native timeline tags for the editable shared rig.
local cursor=1
for _,dir in ipairs(dirs) do for _,act in ipairs(actions) do local tag=base:newTag(cursor,cursor+act[2]-1);tag.name=act[1]..'.'..dir;tag.aniDir=AniDir.FORWARD;local mt=master:newTag(cursor,cursor+act[2]-1);mt.name=tag.name;mt.aniDir=AniDir.FORWARD;cursor=cursor+act[2] end end
base:saveAs(P.root..'/art/characters-base-rig.aseprite')
master:saveAs(P.root..'/art/characters-master.aseprite');P.saveImage(poseContact,P.root..'/public/assets/contact-poses.png')
a:save();P.saveImage(sample,P.root..'/public/assets/contact-characters.png');P.saveSprite(sample,P.root..'/art/contact-characters.aseprite','24 named variants x4 facings');P.json(P.root..'/public/assets/residents.json',residentInfo)
print('Shared rig '..#base.frames..' frames; 24 residents, 1728 packed poses.');
_G.GODMODE_CHARACTER=character
