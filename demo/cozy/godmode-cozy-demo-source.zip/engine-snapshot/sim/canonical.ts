export function canonicalStringify(value:unknown):string {
  if(value===null)return 'null';
  if(typeof value==='string'||typeof value==='boolean')return JSON.stringify(value);
  if(typeof value==='number'){if(!Number.isFinite(value))throw new Error('Non-finite canonical number');return JSON.stringify(value);}
  if(Array.isArray(value))return '['+value.map(canonicalStringify).join(',')+']';
  if(typeof value==='object'){const record=value as Record<string,unknown>;return '{'+Object.keys(record).filter(k=>record[k]!==undefined).sort().map(k=>JSON.stringify(k)+':'+canonicalStringify(record[k])).join(',')+'}';}
  throw new Error('Non-JSON canonical value');
}
const K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
const rotr=(x:number,n:number)=>(x>>>n)|(x<<(32-n));
/** Synchronous SHA-256, identical in browser/worker/headless runtimes. */
export function sha256(text:string):string {
  const input=new TextEncoder().encode(text);const size=Math.ceil((input.length+9)/64)*64;const bytes=new Uint8Array(size);bytes.set(input);bytes[input.length]=0x80;const data=new DataView(bytes.buffer);const bits=input.length*8;data.setUint32(size-8,Math.floor(bits/0x100000000));data.setUint32(size-4,bits>>>0);
  const h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];const w=new Uint32Array(64);
  for(let offset=0;offset<size;offset+=64){for(let i=0;i<16;i++)w[i]=data.getUint32(offset+i*4);for(let i=16;i<64;i++){const a=w[i-15],b=w[i-2];w[i]=(w[i-16]+(rotr(a,7)^rotr(a,18)^(a>>>3))+w[i-7]+(rotr(b,17)^rotr(b,19)^(b>>>10)))>>>0;}let[a,b,c,d,e,f,g,v]=h;for(let i=0;i<64;i++){const t1=(v+(rotr(e,6)^rotr(e,11)^rotr(e,25))+((e&f)^(~e&g))+K[i]+w[i])>>>0;const t2=((rotr(a,2)^rotr(a,13)^rotr(a,22))+((a&b)^(a&c)^(b&c)))>>>0;v=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;}const next=[a,b,c,d,e,f,g,v];for(let i=0;i<8;i++)h[i]=(h[i]+next[i])>>>0;}
  return h.map(n=>n.toString(16).padStart(8,'0')).join('');
}
export const hashValue=(value:unknown)=>sha256(canonicalStringify(value));
